library my_prj.globals;

bool isLoggedIn = false;
List<Item> Cart = List();
List<String> itemidlist = List();
List<int> itemcount = List();
List<Userinfo> userlist = List();
List<OrderDetials> OrderDetialsList = List();


int count =0 ;
class Item {
  final String itemname;
  final String imagename;
  final String itmprice;
  final String id;

  Item({this.itemname, this.imagename, this.itmprice, this.id});
  factory Item.fromJson(Map<String, dynamic> json) {
    return new Item(
      itemname: json['name'],
      itmprice: json['price'],
      imagename: json['image'],
      id: json['id'],
    );
  }
}

class OrderDetials {
   String items ="";
   String address="";
   String address_text ='0';
   String comments='0';
   String Date='0';
 String stats='0';


  OrderDetials({this.items, this.address, this.address_text, this.comments, this.Date,this.stats});
  factory OrderDetials.fromJson(Map<String, dynamic> json) {
    return new OrderDetials(
      address: json['address'],
      comments: json['comments'],
       Date: json['Date'],
         stats: json['stats'],
      items: json['items'],
      address_text: json['address_text'],


    );
}


}

 
 
 class Userinfo {
  final String  id;
   final String  email;
   final String  phone;
   final String  name;
   final String  adress;
   final String  town;
  
  Userinfo({this.id,this.email,this.phone,this.name,this.adress,this.town});
  factory Userinfo.fromJson(Map<String, dynamic> parsedJson){


  return Userinfo(
    id: parsedJson['online_id'],
    email: parsedJson['email'],
    phone: parsedJson['phone'],
    name: parsedJson['full_name'],
    adress: parsedJson['address'],
    town: parsedJson['Town'],
   
  );
}
}